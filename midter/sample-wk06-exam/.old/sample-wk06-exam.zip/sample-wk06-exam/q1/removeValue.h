// removeValue.h 
// Written by Ashesh Mahidadia, August 2017

void removeValue(DLList L, int value);



